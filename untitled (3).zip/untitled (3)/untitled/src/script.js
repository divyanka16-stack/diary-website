const cover = document.getElementById("cover");
const pages = document.querySelectorAll(".page");
const openButton = document.getElementById("openDiary");
const nextButtons = document.querySelectorAll(".next-btn");

let currentPage = 0;
let isTurning = false;

const FLIP_TIME = 800;

// ---------------- OPEN DIARY ----------------

openButton.addEventListener("click", () => {
  if (isTurning) return;

  cover.classList.add("hidden");

  pages.forEach((page) => {
    page.classList.add("hidden");
    page.classList.remove("flipping-in", "flipping-out");
  });

  currentPage = 0;

  const firstPage = pages[0];

  firstPage.classList.remove("hidden");
  firstPage.classList.add("flipping-in");

  setTimeout(() => {
    firstPage.classList.remove("flipping-in");
  }, FLIP_TIME);
});


// ---------------- NEXT PAGE ----------------

nextButtons.forEach((button) => {
  button.addEventListener("click", () => {

    if (isTurning) return;
    if (currentPage >= pages.length - 1) return;

    isTurning = true;

    const current = pages[currentPage];
    const next = pages[currentPage + 1];

    // Hide all pages except current + next
    pages.forEach((page, index) => {
      if (index !== currentPage && index !== currentPage + 1) {
        page.classList.add("hidden");
        page.classList.remove("flipping-in", "flipping-out");
      }
    });

    // Prepare next page
    next.classList.remove("hidden");
    next.classList.add("flipping-in");

    // Flip current page
    current.classList.add("flipping-out");

    setTimeout(() => {

      current.classList.add("hidden");
      current.classList.remove("flipping-out");

      next.classList.remove("flipping-in");

      currentPage++;
      isTurning = false;

    }, FLIP_TIME);

  });
});